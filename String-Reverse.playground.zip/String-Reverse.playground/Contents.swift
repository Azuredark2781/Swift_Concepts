import Foundation

//In-built Function
let str = "Hello, world!"
let reversed = String(str.reversed())
print(reversed)

//Custome Methos
func reverse(_ s: String) -> String {
 var str = ""
 //.characters gives the character view of the string passed. You can think of it as array of characters.
 for character in s.characters {
    str = "\(character)" + str
    //This will help you understand the logic. 
    //!+""
    //p+!
    //l+p! ... goes this way
    print ( str)
 }
 return str
}
print (reverse("!pleH"))


/* Objectic-C Version */

/* NSString *name = @"abcdefghi";
int len = [name length];
NSMutableString *reverseName = [[NSMutableString alloc] initWithCapacity:len];

 for(int i=len-1;i>=0;i--)
 {
     [reverseName appendFormat:[NSString stringWithFormat:@"%c",[name characterAtIndex:i]]];

 }
NSLog(@"%@",reverseName); */