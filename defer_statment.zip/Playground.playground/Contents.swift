import Foundation

func doSomething() {
defer { print("1")}
defer { print("2")}
defer { print("3")}

defer { print("4")}
defer { print("5")}
defer { print("6")}
}

doSomething()